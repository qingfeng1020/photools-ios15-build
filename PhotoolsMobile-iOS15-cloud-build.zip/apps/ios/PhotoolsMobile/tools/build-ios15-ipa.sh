#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
command -v xcodebuild >/dev/null || { echo "需要 macOS 和完整 Xcode"; exit 1; }
command -v xcodegen >/dev/null || { echo "请先安装 XcodeGen: brew install xcodegen"; exit 1; }
swift test
xcodegen generate
BUILD_DIR="$(pwd)/build-ios15"
xcodebuild -project PhotoolsMobile.xcodeproj -scheme PhotoolsMobile -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' -derivedDataPath "$BUILD_DIR" ARCHS=arm64 ONLY_ACTIVE_ARCH=NO IPHONEOS_DEPLOYMENT_TARGET=15.0 CODE_SIGNING_ALLOWED=NO build
APP="$BUILD_DIR/Build/Products/Release-iphoneos/PhotoolsMobile.app"
test -d "$APP"
STAGE=$(mktemp -d)
trap 'rm -rf "$STAGE"' EXIT
mkdir -p "$STAGE/Payload"
cp -R "$APP" "$STAGE/Payload/"
codesign --force --deep --sign - "$STAGE/Payload/PhotoolsMobile.app"
mkdir -p dist
OUTPUT="$(pwd)/dist/PhotoolsMobile-iOS15-arm64-$(date +%Y%m%d-%H%M%S).ipa"
(cd "$STAGE" && /usr/bin/zip -qry "$OUTPUT" Payload)
echo "已打包: $OUTPUT"
echo "此包使用临时签名，需要 TrollStore 重签；仍需 iPhone 6s 真机验证。"
