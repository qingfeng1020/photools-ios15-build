import SwiftUI
import UniformTypeIdentifiers

/// 尼康相机配对向导视图
public struct PairingGuideView: View {
    @Environment(\.dismiss) private var dismiss
    @ObservedObject var coordinator = CameraSyncCoordinator.shared

    @State private var showingImporter = false
    @State private var importMessage = ""
    @State private var showingImportResult = false
    public init() {}

    public var body: some View {
        CompatibleNavigationView {
            List {
                Section("添加相机，无需重新编译") {
                    Button("导入相机凭据 JSON") { showingImporter = true }
                    Text("选择您自己的 camera_credentials.json。凭据保存在本机，可用于多台相机。尼享连接过不代表本应用可以自动取得配对密钥。")
                        .font(.caption).foregroundColor(.secondary)
                }

                Section {
                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Image(systemName: "key.fill")
                                .foregroundColor(.blue)
                            Text("纯 BLE 凭据驱动直连机制")
                                .font(.subheadline.bold())
                                .foregroundColor(.blue)
                        }
                        VStack(alignment: .leading, spacing: 4) {
                            Text("• 凭据自动装载：App 启动时已从配置文件自动加载真机握手密钥 (DeviceID / Nonce)；")
                            Text("• 摆脱 SnapBridge：日常连接无需进入相机配对菜单，更无需跳转系统蓝牙设置；")
                            Text("• 相机处于正常取景拍摄界面时，轻点下方「免配对直连」即可瞬间完成 Blowfish 认证！")
                        }
                        .font(.caption)
                        .foregroundColor(.secondary)
                    }
                    .padding(.vertical, 4)

                    VStack(alignment: .leading, spacing: 10) {
                        HStack {
                            Image(systemName: "sparkles")
                                .foregroundColor(.green)
                            Text("摄影巡航模式：开机即连")
                                .font(.subheadline.bold())
                                .foregroundColor(.green)
                        }
                        VStack(alignment: .leading, spacing: 4) {
                            Text("• 在主界面开启「一键巡航模式」，App 将在后台持续守护；")
                            Text("• 拍摄中相机开机或半按快门唤醒，iPhone 将在 1 秒内自动重连并注入高精 WGS-84 坐标！")
                        }
                        .font(.caption)
                        .foregroundColor(.secondary)
                    }
                    .padding(.vertical, 4)
                }

                Section("附近扫描到的尼康设备 (\(coordinator.discoveredCameras.count))") {
                    if coordinator.discoveredCameras.isEmpty {
                        HStack {
                            ProgressView()
                                .scaleEffect(0.8)
                            Text("正在全频段扫描附近的尼康相机广播...")
                                .font(.caption)
                                .foregroundColor(.secondary)
                        }
                        .padding(.vertical, 8)
                    } else {
                        ForEach(coordinator.discoveredCameras) { item in
                            HStack {
                                VStack(alignment: .leading, spacing: 4) {
                                    HStack {
                                        Text(item.displayName)
                                            .font(.subheadline.bold())
                                        if item.isPrePaired {
                                            Text("已有配对广播")
                                                .font(.system(size: 10, weight: .bold))
                                                .padding(.horizontal, 6)
                                                .padding(.vertical, 2)
                                                .background(Color.green.opacity(0.15))
                                                .foregroundColor(.green)
                                                .cornerRadius(6)
                                        } else {
                                            Text("未识别凭据")
                                                .font(.system(size: 10, weight: .bold))
                                                .padding(.horizontal, 6)
                                                .padding(.vertical, 2)
                                                .background(Color.blue.opacity(0.15))
                                                .foregroundColor(.blue)
                                                .cornerRadius(6)
                                        }
                                    }
                                    Text("信号强度 RSSI: \(item.rssi) dBm\(item.discoveredDeviceID != nil ? " • DeviceID: 0x\(String(item.discoveredDeviceID!, radix: 16).uppercased())" : "")")
                                        .font(.caption2)
                                        .foregroundColor(.secondary)
                                }
                                Spacer()
                                Button(item.isPrePaired ? "尝试直连" : "尝试配对") {
                                    coordinator.connectDiscoveredCamera(item)
                                    dismiss()
                                }
                                .buttonStyle(.borderedProminent)
                                .tint(item.isPrePaired ? .green : .blue)
                                .font(.caption.bold())
                            }
                            .padding(.vertical, 4)
                        }
                    }
                }
            }
            .navigationTitle("配对新相机")
            #if os(iOS)
            .navigationBarTitleDisplayMode(.inline)
            #endif
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("关闭") {
                        dismiss()
                    }
                }
                ToolbarItem(placement: .primaryAction) {
                    Button("刷新") {
                        coordinator.discoveredCameras.removeAll()
                        coordinator.bluetoothManager.startScanning()
                    }
                }
            }
            .fileImporter(isPresented: $showingImporter, allowedContentTypes: [.json]) { result in
                do {
                    let url = try result.get()
                    let access = url.startAccessingSecurityScopedResource()
                    defer { if access { url.stopAccessingSecurityScopedResource() } }
                    let devices = try CameraConfigLoader.shared.loadValidatedImport(from: Data(contentsOf: url))
                    for device in devices { coordinator.saveCamera(device) }
                    importMessage = "已保存 \(devices.count) 台相机凭据，请刷新扫描后连接。"
                } catch {
                    importMessage = "导入失败，请检查 JSON 格式、名称及 DeviceID / Nonce。"
                }
                showingImportResult = true
            }
            .alert("相机凭据导入", isPresented: $showingImportResult) {
                Button("好", role: .cancel) {}
            } message: { Text(importMessage) }
            .onAppear {
                coordinator.bluetoothManager.startScanning()
            }
        }
    }
}
